﻿Thank you for downloading Ozark.  
Ozark is a Roblox™ executor that lets you execute Lua™ Programming Language scripts.

This software requires an active internet connection to function properly.  
Ozark connects to servers to install, fix, or add necessary files.

When first downloading Ozark, you will receive "Ozark Bootstrapper.exe".  
Keep this executable in a folder (preferably the one it came with), as it will install Ozark’s files directly into that folder.

Run the bootstrapper executable to install Ozark.  
If files are removed or corrupted, the bootstrapper may reinstall missing or damaged files.  
If Ozark requires an update, it will automatically launch the bootstrapper which will complete the update process.

Below you can view the VirusTotal scan. This confirms that Ozark is not malicious and is safe.  
These scans have been made without the API in place and only showcase the legitimacy of the Ozark app itself.

VirusTotal Scan: https://www.virustotal.com/gui/file/42bb472448b06f4122660d9f2e977baa6822c31bad4d78298ca54c0f8afbb0bf

---

Important:  
Use Ozark responsibly and in accordance with Roblox’s terms of service.  
The developers are not responsible for any misuse or violations of platform rules.

Ozark requires administrator permissions to function properly. This is solely to allow certain necessary system configurations, such as adding the Ozark directory to Windows Defender exclusions. No other elevated actions are performed.

Support:  
For help or questions, join our Discord server.  
Discord Server Invitation: https://discord.gg/ozark

Disclaimer:  
This software is provided “as is” without warranty of any kind. Use at your own risk.

---

Thank you for choosing Ozark!
